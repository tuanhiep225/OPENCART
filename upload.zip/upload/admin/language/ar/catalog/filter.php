<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'الفلاتر';

// Text
$_['text_success']      = 'تم التعديل !';
$_['text_list']         = 'القائمة';
$_['text_add']          = 'ادراج';
$_['text_edit']         = 'تحرير';
$_['text_group']        = 'مجموعة الفلتر';
$_['text_value']        = 'قيمة الفلتر';

// Column
$_['column_group']        = 'اسم الفلتر';
$_['column_sort_order']   = 'فرز الطلب';
$_['column_action']       = 'تحرير';

// Entry
$_['entry_group']        = 'اسم مجموعة الفلتر';
$_['entry_name']         = 'اسم الفلتر';
$_['entry_sort_order']   = 'فرز الطلب';

// Error
$_['error_permission']   = 'تحذير: أنت لاتمتلك صلاحية التعديل !';
$_['error_group']        = 'اسم مجموعة الفلتر يجب أن تكون بين 1 و 64 رمزاً !';
$_['error_name']         = 'الاسم يجب أن يكون بين 1 و 64 رمز !';
